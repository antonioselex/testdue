# insecure-coding-examples
Code examples for the talk Secure Coding Practices in C++ 
