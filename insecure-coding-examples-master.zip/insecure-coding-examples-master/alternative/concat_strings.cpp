#include <iostream>

int main() {

  std::string first = "Hello ";
  std::string second = "World";
  std::string buffer = first + second;

  std::cout << buffer << "\n";
}
